from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='home'),
    path('golovne', views.golovne, name='golovne'),
    path('news', views.news, name='news'),
    path('news/news-1', views.news1, name='news1'),
    path('poslug', views.poslug, name='poslug'),
    path('asvita', views.osvita, name='osvita')
]
