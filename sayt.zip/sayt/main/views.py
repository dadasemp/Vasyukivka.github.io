from django.shortcuts import render
from .models import Task


def index(request):
    tasks = Task.objects.order_by('id')[:5]
    return render(request, ('main/index.html'), {'title': 'Головна сторінка', 'tasks': tasks})
def golovne(request):
    return render(request, ('main/golovne.html'))
def news(request):
    tasks = Task.objects.order_by('id')[:5]
    return render(request, ('main/news.html'), {'title': 'Новини', 'tasks': tasks})
def news1(request):
    return render(request, ('main/news1.html'))
def poslug(request):
    return render(request, ('main/poslug.html'))
def osvita(request):
    return render(request, ('main/osvita.html'))
